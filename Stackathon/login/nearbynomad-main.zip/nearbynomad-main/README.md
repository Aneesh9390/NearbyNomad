# nearbynomad
group project of batch 34
